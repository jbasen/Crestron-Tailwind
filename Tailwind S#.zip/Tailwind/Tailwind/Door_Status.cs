﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;

namespace Tailwind_Integration
{
	public class Door_Status
	{
		public string result { get; set; }
		public string product { get; set; }
		public string dev_id { get; set; }
		public string proto_ver { get; set; }
		public int door_num { get; set; }
		public int night_mode_en { get; set; }
		public string fw_ver { get; set; }
		public int led_brightness { get; set; }
		public int router_rssi { get; set; }
		public Doors data { get; set; }
		public Notify notify { get; set; }

		//****************************************************************************************
		// 
		//  Parse	-   Parse iQ3 Status Message JSON
		// 
		//****************************************************************************************
		public static Door_Status Parse(string JSON)
		{
			#region Debug Message
			CrestronConsole.PrintLine("Tailwind - Door_Status - Parse - " + JSON);
			#endregion Debug Message

			try
			{
				return JsonConvert.DeserializeObject<Door_Status>(JSON);
			}
			catch (Exception e)
			{
				string err = "Tailwind - Door_Status - Parse - Error Parsing Door Status JSON: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Crestron.SimplSharp.ErrorLog.Notice("Tailwind - Door_Status - Parse - " + JSON + "\n");
				return null;
			}
		}
	}

	public class Doors
	{
		public Door door1 { get; set; }
		public Door door2 { get; set; }
		public Door door3 { get; set; }
	}

	public class Door
	{
		public int index { get; set; }
		public string status { get; set; }
		public int lockup { get; set; }
		public int disabled { get; set; }
	}

	public class Notify
	{
		public int door_idx { get; set; }
		public string @event { get; set; }
	}
}