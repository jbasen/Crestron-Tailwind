﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;

namespace Tailwind_Integration
{
	public class Door_Status
	{
		public string result { get; set; }
		public string product { get; set; }
		public string dev_id { get; set; }
		public string proto_ver { get; set; }
		public int door_num { get; set; }
		public int night_mode_en { get; set; }
		public string fw_ver { get; set; }
		public Doors data { get; set; }

		//****************************************************************************************
		// 
		//  Parse	-   Parse iQ3 Status Message JSON
		// 
		//****************************************************************************************
		public static Door_Status Parse(string JSON)
		{
			#region Debug Message
			CrestronConsole.PrintLine("Tailwind - Door_Status - Parse");
			#endregion Debug Message

			try
			{
				return JsonConvert.DeserializeObject<Door_Status>(JSON);
			}
			catch (Exception e)
			{
				string err = "Tailwind - Door_Status - Parse - Error Parsing Door Status JSON: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return null;
			}
		}
	}

	public class Doors
	{
		public Door door1 { get; set; }
		public Door door2 { get; set; }
		public Door door3 { get; set; }
	}

	public class Door
	{
		public string status { get; set; }
		public int lockup { get; set; }
		public int enabled { get; set; }
	}

}