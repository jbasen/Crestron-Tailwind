﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Crestron.SimplSharp.Net.Http;

namespace Tailwind_Integration
{
	#region Classes
	//Event Classes
	public class SerialChangeEventArgs : EventArgs
	{
		public string Device_IP { get; set; }
		public string Door_1_State { get; set; }
		public string Door_2_State { get; set; }
		public string Door_3_State { get; set; }

		public string Light_Mode { get; set; }

		public SerialChangeEventArgs()
		{
		}

		public SerialChangeEventArgs(string Device_IP, string Door_1_State, string Door_2_State, string Door_3_State, string Light_Mode)
		{
			#region Set Class Data Elements from Parameters
			this.Device_IP = Device_IP;
			this.Door_1_State = Door_1_State;
			this.Door_2_State = Door_2_State;
			this.Door_3_State = Door_3_State;
			this.Light_Mode = Light_Mode;
			#endregion
		}
	}

	public static class SignalChangeEvents
	{
		public static event SerialChangedEventHandler onSerialValueChange;

		public static void SerialValueChange(string Device_IP, string Door_1_State, string Door_2_State, string Door_3_State, string Light_Mode)
		{
			SignalChangeEvents.onSerialValueChange(new SerialChangeEventArgs(Device_IP, Door_1_State, Door_2_State, Door_3_State, Light_Mode));
		}
	}
	#endregion

	#region Delegates
	public delegate void SerialChangedEventHandler(SerialChangeEventArgs e);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Tailwind
	{
		#region Declarations
		private static HttpServer Server;
		private static bool Server_Running = false;
		private static Debug_Options Debug;
		private static string Processor_IP;
		private static string Processor_Port;
		private static string Tailwind_Token;
		#endregion

		//****************************************************************************************
		// 
		//  Tailwind	-	Default Constructor
		// 
		//****************************************************************************************
		public Tailwind()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialization
		// 
		//****************************************************************************************
		public short Initialize(string Processor_IP, string Processor_Port, string Tailwind_Token, short Debug)
		{
			#region Save Parameters
			Tailwind.Processor_IP = Processor_IP;
			Tailwind.Processor_Port = Processor_Port;
			Tailwind.Tailwind_Token = Tailwind_Token;
			#endregion

			Set_Debug_Message_Output(Debug);

			#region Create Server for capturing responses from Tailwind Devices
			if (Server_Running == false)                                        //don't create server if already running
			{
				if (Create_Server(Processor_IP, Processor_Port) == false)
				{
					Debug_Message("Initialize", "Create Server Failed");
					return 0;
				}
			}
			#endregion

			Debug_Message("Initialize", "SUCCESS");
			return 1;
		}

		//****************************************************************************************
		// 
		//  Create_Server	-	Setup http server to receive status messages from Tailwind devices
		// 
		//****************************************************************************************
		private bool Create_Server(string Processor_IP, string Processor_Port)
		{
			try
			{
				//Create a new instance of a server
				Server = new HttpServer();
				//Set the server's IP address
				Server.ServerName = Processor_IP;
				//Set the server's port
				Server.Port = int.Parse(Processor_Port);
				//Assign an event handling method to the server
				Server.OnHttpRequest += new OnHttpRequestHandler(HTTPRequestEventHandler);
				Server.Active = true;
				//save that server is running so initialization can possibly be run again to get device status
				Server_Running = true;
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Tailwind - Create_Server - Can't create http server: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Tailwind - Create_Server - Can't create http server: " + e + "\n");
				Server.Active = false;
				return false;
			}

			return true;
		}

		//****************************************************************************************
		// 
		//  HTTPRequestEventHandler	-	Handler to receive messages sent from Tailwind Devices 
		// 
		//****************************************************************************************
		private void HTTPRequestEventHandler(Object sender, OnHttpRequestArgs requestArgs)
		{
			//Get IP Address of Tailwind device that sent message
			string Device_IP = requestArgs.Connection.RemoteEndPointAddress;
			Debug_Message("HTTPRequestEventHandler", "Device_IP = " + Device_IP);
			Debug_Message("HTTPRequestEventHandler", "ContentString = " + requestArgs.Request.ContentString);

			//Parse JSON in Content String and pass back to S+
			Parse_Tailwind_JSON(Device_IP, requestArgs.Request.ContentString);
		}

		//****************************************************************************************
		// 
		//  Parse_Tailwind_JSON	-	Parse JSON returned by Tailwind device
		//							and pass to S+
		// 
		//****************************************************************************************
		private void Parse_Tailwind_JSON(string Device_IP, string json)
		{
			string door1_status = "";
			string door2_status = "";
			string door3_status = "";

			Debug_Message("Parse_Tailwind_JSON", "JSON = " + json);
			
			//Parse Product
			string json_for_product_parse = json.Replace(" ", string.Empty);	//remove spaces for parsing
			string product = Parse_Data_Substring(json_for_product_parse, "", "\"product\":\"", "\"");

			//Parse json based on product
			if (string.IsNullOrEmpty(product) == true)
			{
				Debug_Message("Parse_Tailwind_JSON", "product = null/empty");
				return;
			}
			else if (product == "iQ3")
			{
				Door_Status door_status = Door_Status.Parse(json);
				if (door_status != null)
				{
					//Don't pass back nulls
					if (door_status.data.door1 != null)
					{
						door1_status = string.IsNullOrEmpty(door_status.data.door1.status) ? "" : door_status.data.door1.status;
					}

					if (door_status.data.door2 != null)
					{
						door2_status = string.IsNullOrEmpty(door_status.data.door2.status) ? "" : door_status.data.door2.status;
					}

					if (door_status.data.door3 != null)
					{
						door3_status = string.IsNullOrEmpty(door_status.data.door3.status) ? "" : door_status.data.door3.status;
					}

					if (door_status.notify != null)
					{
						switch (door_status.notify.door_idx)
						{
							case 0:
								if (string.IsNullOrEmpty(door_status.notify.@event) == false)
								{
									door1_status = door_status.notify.@event;
								}
								break;

							case 1:
								if (string.IsNullOrEmpty(door_status.notify.@event) == false)
								{
									door2_status = door_status.notify.@event;
								}
								break;

							case 2:
								if (string.IsNullOrEmpty(door_status.notify.@event) == false)
								{
									door3_status = door_status.notify.@event;
								}
								break;
						}
					}

					//pass data back to S+
					SignalChangeEvents.SerialValueChange(Device_IP, door1_status, door2_status, door3_status, "");
				}
				else
				{
					#region Debug Message
					Debug_Message("Parse_Tailwind_JSON", "Parse Door Status JSON - Returned null");
					#endregion Debug Message
				}
			}
			else if (product == "light")
			{
				Light_Status light_status = Light_Status.Parse(json);

				string light_mode = string.IsNullOrEmpty(light_status.data.mode) ? "" : light_status.data.mode;

				//pass data back to S+
				SignalChangeEvents.SerialValueChange(Device_IP, "", "", "", light_mode);
			}
			else
			{
				Debug_Message("Parse_Tailwind_JSON", "Unknown product = " + product);
				return;
			}
		}

		//****************************************************************************************
		// 
		//  Set_Status_Report_URL	-	Tell Tailwind device where to send status update messages
		// 
		//****************************************************************************************
		public void Set_Status_Report_URL(string Device_IP)
		{

			Debug_Message("Set_Status_Report_URL", "");

			#region Create url
			string url = "http://" + Device_IP + "/json";
			Debug_Message("Set_Status_Report_URL", "URL: " + url);
			#endregion

			#region JSON
			string json = "{\"product\": \"iQ3\",\"version\": \"0.1\",\"data\":{\"type\":\"set\",\"name\":\"notify_url\",\"value\":{\"url\":\"http://"
				+ Tailwind.Processor_IP + ":" + Tailwind.Processor_Port + "\",\"proto\":\"http\",\"enable\":1}}}";

			Debug_Message("Set_Status_Report_URL", "JSON: " + json);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Post;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("charset", "utf8");
				request.Header.SetHeaderValue("Accept", "*/*");
				request.Header.AddHeader(new HttpHeader("TOKEN", Tailwind.Tailwind_Token));
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));

				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Tailwind - Set_Status_Report_URL - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Set_Status_Report_URL", "ContentString = " + ContentString);
				}
			}
			catch (Exception e)
			{
				string err = "Tailwind - Set_Status_Report_URL - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Device_Status	-	Get status of garage door or light
		// 
		//****************************************************************************************
		public void Get_Device_Status(string Device_IP)
		{
			Debug_Message("Get_Device_Status", "Device_IP = " + Device_IP);

			#region Create url
			string url = "http://" + Device_IP + "/json";
			Debug_Message("Get_Device_Status", "URL: " + url);
			#endregion

			#region JSON
			string json = "{\"version\":\"0.1\",\"data\":{\"type\":\"get\",\"name\":\"dev_st\"}}";
			Debug_Message("Get_Device_Status", "JSON: " + json);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Post;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("charset", "utf8");
				request.Header.SetHeaderValue("Accept", "*/*");
				request.Header.AddHeader(new HttpHeader("TOKEN", Tailwind.Tailwind_Token));
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));

				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Tailwind - Get_Device_Status - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					//Parse JSON in Content String and pass back to S+
					string ContentString = response.ContentString;
					Debug_Message("Get_Device_Status", "ContentString = " + ContentString);
					Parse_Tailwind_JSON(Device_IP, ContentString);
				}
			}
			catch (Exception e)
			{
				string err = "Tailwind - Get_Device_Status - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_Garage_Door_Command	-	Send command to open/close a garage door
		// 
		//****************************************************************************************
		public void Send_Garage_Door_Command(string Device_IP, short Door_Index, string Command)
		{

			Debug_Message("Send_Garage_Door_Command", "Device_IP = " + Device_IP + "Door_Index = " + Door_Index + ", Command = " + Command);

			#region Create url
			string url = "http://" + Device_IP + "/json";
			Debug_Message("Send_Garage_Door_Command", "URL: " + url);
			#endregion

			#region JSON
			string json = "{\"product\": \"iQ3\",\"version\": \"0.1\",\"data\":{\"type\": \"set\",\"name\":\"door_op\",\"value\":{\"door_idx\":" + Door_Index + ",\"cmd\":\"" + Command + "\"}}}";
			Debug_Message("Send_Garage_Door_Command", "JSON: " + json);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Post;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("charset", "utf8");
				request.Header.SetHeaderValue("Accept", "*/*");
				request.Header.AddHeader(new HttpHeader("TOKEN", Tailwind.Tailwind_Token));
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));

				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Tailwind - Send_Garage_Door_Command - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Send_Garage_Door_Command", "ContentString = " + ContentString);
				}
			}
			catch (Exception e)
			{
				string err = "Tailwind - Send_Garage_Door_Command - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Set_Light_Mode	-	Sets the mode (auto/manual) of a light
		// 
		//****************************************************************************************
		public void Set_Light_Mode(string Device_IP, string Mode)
		{
			Debug_Message("Set_Light_Mode", "Device_IP = " + Device_IP + "Mode = " + Mode);

			#region Create url
			string url = "http://" + Device_IP + "/json";
			Debug_Message("Set_Light_Mode", "URL: " + url);
			#endregion

			#region JSON
			string json = "{\"product\":\"light\",\"version\":\"0.1\",\"data\":{\"type\":\"set\",\"name\":\"dev_op\",\"value\":{\"mode\":\"" + Mode + "\"}}}";
			Debug_Message("Set_Light_Mode", "JSON: " + json);
			#endregion

			#region Send Command
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Format http client request
				request.KeepAlive = false;
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Post;
				request.Header.ContentType = "application/json";
				request.Header.SetHeaderValue("charset", "utf8");
				request.Header.SetHeaderValue("Accept", "*/*");
				request.Header.AddHeader(new HttpHeader("TOKEN", Tailwind.Tailwind_Token));
				request.ContentString = json;
				request.Header.SetHeaderValue("Content-Length", Convert.ToString(json.Length));

				request.Url.Parse(url);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Tailwind - Set_Light_Mode - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				}
				else
				{
					string ContentString = response.ContentString;
					Debug_Message("Set_Light_Mode", "ContentString = " + ContentString);
				}
			}
			catch (Exception e)
			{
				string err = "Tailwind - Set_Light_Mode - Error Sending Device Command: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Tailwind - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Tailwind - Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Tailwind - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Tailwind - Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Tailwind - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Tailwind - Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			return s.Substring(index1, index2 - index1);
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Tailwind.Debug = Debug_Options.None;
					break;

				case 1:
					Tailwind.Debug = Debug_Options.Console;
					break;

				case 2:
					Tailwind.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Tailwind.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Tailwind - " + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Tailwind - " + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}
	}
}
