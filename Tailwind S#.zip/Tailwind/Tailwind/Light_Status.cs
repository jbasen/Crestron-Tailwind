﻿using System;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;

namespace Tailwind_Integration
{
	public class Light_Status
	{
		public string result { get; set; }
		public string product { get; set; }
		public string dev_id { get; set; }
		public string proto_ver { get; set; }
		public int pwm_channel { get; set; }
		public string fw_ver { get; set; }
		public Light_Data data { get; set; }

		//****************************************************************************************
		// 
		//  Parse	-   Parse Tailwind Light Status Message JSON
		// 
		//****************************************************************************************
		public static Light_Status Parse(string JSON)
		{
			#region Debug Message
			CrestronConsole.PrintLine("Tailwind - Light_Status - Parse");
			#endregion Debug Message

			try
			{
				return JsonConvert.DeserializeObject<Light_Status>(JSON);
			}
			catch (Exception e)
			{
				string err = "Tailwind - Light_Status - Parse - Error Parsing Door Status JSON: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				return null;
			}
		}
	}

	public class Light_Data
	{
		public string mode { get; set; }
		public Light light { get; set; }
		public Radar radar { get; set; }
	}

	public class Light
	{
		public int power { get; set; }
		public int frequency { get; set; }
	}

	public class Radar
	{
		public int distance { get; set; }
		public int lux { get; set; }
		public int delay { get; set; }
	}
}